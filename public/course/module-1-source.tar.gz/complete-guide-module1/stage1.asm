bits 16
org 0x7c00

jmp 0x0000:start
start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7c00
    cld
    mov [boot_drive], dl
    sti

    ; BIOS Enhanced Disk Drive services are mandatory for this lab.
    mov ah, 0x41
    mov bx, 0x55aa
    push ds
    int 0x13
    pop ds
    jc fatal
    cmp bx, 0xaa55
    jne fatal
    test cx, 1
    jz fatal
    call read_disk
    jc fatal
    mov dl, [boot_drive]
    jmp 0x0000:0x8000

%define LOAD_SECTORS 8
%define LOAD_SEGMENT 0x0800
%define LOAD_LBA 1
%include "disk.inc"

; Reserve the conventional partition-table area. No partitions here.
times 446-($-$$) db 0
times 64 db 0
dw 0xaa55
