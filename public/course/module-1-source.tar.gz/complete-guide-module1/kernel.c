#include <stddef.h>
#include <stdint.h>

static volatile uint32_t bss_probe;
static volatile uint32_t data_probe = 0x12345678;

static inline void outb(uint16_t port, uint8_t value) {
    __asm__ volatile ("outb %0, %1" : : "a"(value), "Nd"(port));
}

static inline uint8_t inb(uint16_t port) {
    uint8_t value;
    __asm__ volatile ("inb %1, %0" : "=a"(value) : "Nd"(port));
    return value;
}

static void serial_init(void) {
    outb(0x3f9, 0x00);             /* Disable UART interrupts. */
    outb(0x3fb, 0x80);             /* Enable divisor latch. */
    outb(0x3f8, 0x03);             /* 38400 baud. */
    outb(0x3f9, 0x00);
    outb(0x3fb, 0x03);             /* 8 bits, no parity, 1 stop bit. */
    outb(0x3fa, 0xc7);             /* Enable and clear FIFOs. */
    outb(0x3fc, 0x03);             /* Assert DTR and RTS. */
}

static void serial_putc(char ch) {
    for (uint32_t tries = 0; tries < 100000; ++tries) {
        if (inb(0x3fd) & 0x20) {
            outb(0x3f8, (uint8_t)ch);
            return;
        }
    }
    /* A missing UART must not hang the kernel. */
}

void kernel_main(void) {
    volatile uint16_t *const vga = (volatile uint16_t *)0xb8000;
    const char *message = "Module 1: protected-mode C kernel OK";
    serial_init();
    if (bss_probe != 0 || data_probe != 0x12345678)
        message = "FAIL: C runtime initialization";
    for (size_t i = 0; i < 80 * 25; ++i)
        vga[i] = 0x0720;
    for (size_t i = 0; message[i] != '\0'; ++i) {
        vga[i] = (uint16_t)(0x0f00 | (uint8_t)message[i]);
        serial_putc(message[i]);
    }
    serial_putc('\r');
    serial_putc('\n');
    for (;;)
        __asm__ volatile ("cli; hlt");
}
