"""Additional release checks: reject malformed images; inspect CPU and C ABI."""
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile
import time

root = Path(__file__).resolve().parent
build = root / "build"

with tempfile.TemporaryDirectory() as temporary:
    scratch = Path(temporary)
    for name in ("stage1.bin", "stage2.bin", "kernel.bin"):
        shutil.copyfile(build / name, scratch / name)
    boot = (scratch / "stage1.bin").read_bytes()
    (scratch / "stage1.bin").write_bytes(boot[:510] + b"\0\0")
    result = subprocess.run([sys.executable, str(root / "mkimage.py"), str(scratch)],
                            capture_output=True, text=True)
    assert result.returncode != 0 and "invalid boot sector" in result.stderr
    (scratch / "stage1.bin").write_bytes(boot)
    (scratch / "kernel.bin").write_bytes(bytes(16385))
    result = subprocess.run([sys.executable, str(root / "mkimage.py"), str(scratch)],
                            capture_output=True, text=True)
    assert result.returncode != 0 and "32-sector slot" in result.stderr
    print("PASS: image builder rejects invalid signature and oversized kernel")

    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    qemu = subprocess.Popen([
        "qemu-system-i386", "-machine", "pc", "-accel", "tcg", "-m", "32M",
        "-drive", f"file={build / 'os.img'},format=raw,if=ide", "-boot", "c",
        "-display", "none", "-serial", "none", "-monitor", "none", "-nic", "none",
        "-no-reboot", "-no-shutdown", "-snapshot", "-S",
        "-gdb", f"tcp:127.0.0.1:{port}",
    ], stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    try:
        # Let QEMU create its GDB listener before starting the client.
        time.sleep(0.5)
        commands = [
            "set pagination off", "set confirm off",
            f"target remote 127.0.0.1:{port}",
            "hbreak *_start", "continue",
            "set variable bss_probe = 0xa5a5a5a5",
            "hbreak *kernel_main", "continue",
            "python assert int(gdb.parse_and_eval('$cr0')) & 1",
            "python assert not (int(gdb.parse_and_eval('$cr0')) & 0x80000000)",
            "python assert int(gdb.parse_and_eval('$cs')) == 8",
            "python assert int(gdb.parse_and_eval('$ds')) == 16",
            "python assert (int(gdb.parse_and_eval('$esp')) & 15) == 12",
            "python assert int(gdb.parse_and_eval('bss_probe')) == 0",
            "python assert int(gdb.parse_and_eval('data_probe')) == 0x12345678",
            "python assert not (int(gdb.parse_and_eval('$eflags')) & 0x600)",
            "detach", "quit",
        ]
        argv = ["gdb", "-q", "-nx", "-batch", str(build / "kernel.elf")]
        for command in commands:
            argv += ["-ex", command]
        result = subprocess.run(argv, capture_output=True, text=True, timeout=15)
        if result.returncode or "Error" in result.stderr or "Traceback" in result.stderr:
            raise RuntimeError(result.stdout + result.stderr)
        print("PASS: CR0.PE=1, PG=0, CS=8, DS=16, IF=DF=0, ABI stack aligned")
        print("PASS: poisoned .bss cleared by entry stub; .data intact")
    finally:
        qemu.terminate()
        try:
            qemu.communicate(timeout=3)
        except subprocess.TimeoutExpired:
            qemu.kill()
            qemu.communicate()
