from pathlib import Path
import sys


def require(condition, message):
    if not condition:
        raise SystemExit(message)


build = Path(sys.argv[1])
boot = (build / "stage1.bin").read_bytes()
stage2 = (build / "stage2.bin").read_bytes()
kernel = (build / "kernel.bin").read_bytes()
require(len(boot) == 512 and boot[510:] == b"\x55\xaa",
        "invalid boot sector")
require(len(stage2) == 8 * 512, "stage 2 must occupy exactly 8 sectors")
require(0 < len(kernel) <= 32 * 512, "kernel exceeds 32-sector slot")
image = bytearray(16 * 1024 * 1024)
image[:512] = boot
image[512:9 * 512] = stage2
image[9 * 512:9 * 512 + len(kernel)] = kernel
(build / "os.img").write_bytes(image)
print(f"Built {build / 'os.img'}: kernel {len(kernel)} bytes")
