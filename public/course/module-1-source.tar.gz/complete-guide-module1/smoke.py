from pathlib import Path
import os
import subprocess
import sys
import tempfile
import time

image = Path(sys.argv[1]).resolve()
marker = b"Module 1: protected-mode C kernel OK\r\n"
with tempfile.TemporaryDirectory() as scratch:
    serial = Path(scratch) / "serial.log"
    errors = Path(scratch) / "qemu.log"
    with errors.open("wb") as error_stream:
        process = subprocess.Popen([
            os.environ.get("QEMU", "qemu-system-i386"),
            "-machine", "pc", "-accel", "tcg", "-m", "32M",
            "-drive", f"file={image},format=raw,if=ide",
            "-boot", "c", "-display", "none", "-monitor", "none",
            "-serial", f"file:{serial}", "-nic", "none",
            "-no-reboot", "-no-shutdown", "-snapshot",
        ], stdout=subprocess.DEVNULL, stderr=error_stream)
        passed = False
        try:
            deadline = time.monotonic() + 15
            while time.monotonic() < deadline:
                data = serial.read_bytes() if serial.exists() else b""
                if marker in data:
                    passed = True
                    break
                if process.poll() is not None or b"FAIL:" in data:
                    break
                time.sleep(0.05)
        finally:
            if process.poll() is None:
                process.terminate()
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
    if not passed:
        print(errors.read_text(errors="replace"), file=sys.stderr)
        if serial.exists():
            print(serial.read_text(errors="replace"), file=sys.stderr)
        raise SystemExit("FAIL: kernel boot marker missing")
print("PASS: BIOS -> stage 1 -> stage 2 -> protected-mode C; .data/.bss OK")
