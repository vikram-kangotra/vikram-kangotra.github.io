bits 16
org 0x8000

start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7c00
    cld
    mov [boot_drive], dl
    sti

    ; Explicitly establish 80x25 color text mode before leaving BIOS.
    mov ax, 0x0003
    push ds
    int 0x10
    pop ds
    call read_disk
    jc fatal

    ; Mask legacy IRQ sources and keep IF clear until Module 2's IDT.
    cli
    mov al, 0xff
    out 0x21, al
    out 0xa1, al
    lgdt [gdtr]
    mov eax, cr0
    or eax, 1
    mov cr0, eax
    jmp 0x08:protected_entry

%define LOAD_SECTORS 32
%define LOAD_SEGMENT 0x1000
%define LOAD_LBA 9
%include "disk.inc"

align 8, db 0
gdt:
    dq 0x0000000000000000  ; Null descriptor.
    dq 0x00cf9a000000ffff  ; Ring-0, base 0, 4 GiB, 32-bit code.
    dq 0x00cf92000000ffff  ; Ring-0, base 0, 4 GiB, writable data.
gdt_end:
gdtr:
    dw gdt_end-gdt-1
    dd gdt

bits 32
protected_entry:
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax
    mov esp, 0x70000
    cld
    mov eax, 0x10000
    jmp eax

times 4096-($-$$) db 0
