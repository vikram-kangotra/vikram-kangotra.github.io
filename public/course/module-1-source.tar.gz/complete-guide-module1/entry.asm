bits 32
section .text.entry
global _start
extern kernel_main
extern __bss_start
extern __bss_end

_start:
    cli
    cld
    mov esp, 0x70000
    xor ebp, ebp
    xor eax, eax
    mov edi, __bss_start
    mov ecx, __bss_end
    sub ecx, edi
    rep stosb
    ; ESP is 16-byte aligned immediately before CALL (i386 SysV ABI).
    call kernel_main
.halt:
    cli
    hlt
    jmp .halt

section .note.GNU-stack noalloc noexec nowrite progbits
